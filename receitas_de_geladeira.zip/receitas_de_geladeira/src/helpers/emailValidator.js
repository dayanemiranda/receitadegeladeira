export function emailValidator(email) {
  const re = /\S+@\S+\.\S+/
  if (!email) return "O e-mail não pode estar vazio."
  if (!re.test(email)) return 'Ooops! Precisamos de um e-mail válido.'
  return ''
}
