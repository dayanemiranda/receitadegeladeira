export function nameValidator(name) {
  if (!name) return "O nome não pode estar vazio."
  return ''
}
